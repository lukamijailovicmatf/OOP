module org.example.jan1_2024_grupa {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.jan1_2024_grupa2.zadatak3 to javafx.fxml;
    exports org.example.jan1_2024_grupa2.zadatak3;
}