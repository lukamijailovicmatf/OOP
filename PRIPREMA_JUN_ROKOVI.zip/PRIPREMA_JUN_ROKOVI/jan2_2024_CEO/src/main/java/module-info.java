module org.example.jan2_2024_ceo {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.jan2_2024_ceo to javafx.fxml;
    exports org.example.jan2_2024_ceo;
}