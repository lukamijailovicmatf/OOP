package org.example.primer_roka.zadatak1;

public interface Ispis {
    void prikazi();
}
