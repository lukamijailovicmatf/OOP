module org.example.primer_roka {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.primer_roka.zadatak2 to javafx.fxml;
    exports org.example.primer_roka.zadatak2;
}