module org.example.jan1_2024_grupa2_ceo.zadatak3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.jan1_2024_grupa2_ceo.zadatak3 to javafx.fxml;
    exports org.example.jan1_2024_grupa2_ceo.zadatak3;
}