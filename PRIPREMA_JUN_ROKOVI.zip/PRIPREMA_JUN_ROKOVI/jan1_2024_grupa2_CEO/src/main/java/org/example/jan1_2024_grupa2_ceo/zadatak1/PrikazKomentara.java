package org.example.jan1_2024_grupa2_ceo.zadatak1;

public interface PrikazKomentara {
    String vratiKomentare();
}
