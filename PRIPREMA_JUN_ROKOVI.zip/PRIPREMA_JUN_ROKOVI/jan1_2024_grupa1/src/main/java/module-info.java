module org.example.jan1_2024_grupa {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.jan1_2024_grupa1.zadatak2 to javafx.fxml;
    exports org.example.jan1_2024_grupa1.zadatak2;
}