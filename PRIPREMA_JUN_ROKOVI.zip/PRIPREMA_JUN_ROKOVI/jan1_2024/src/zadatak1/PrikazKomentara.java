package zadatak1;

public interface PrikazKomentara {
    String vratiKomentare();
}