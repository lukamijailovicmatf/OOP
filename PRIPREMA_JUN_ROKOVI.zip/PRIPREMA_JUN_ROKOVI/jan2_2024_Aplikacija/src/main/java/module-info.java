module org.example.jan2_2024_aplikacija {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.jan2_2024_aplikacija to javafx.fxml;
    exports org.example.jan2_2024_aplikacija;
}