module com.example.jun_2017_2018_pokemoni.zadatak1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.jun_2017_2018_pokemoni.zadatak1 to javafx.fxml;
    exports com.example.jun_2017_2018_pokemoni.zadatak1;
}