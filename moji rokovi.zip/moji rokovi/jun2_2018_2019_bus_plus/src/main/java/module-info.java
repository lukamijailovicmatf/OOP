module com.example.jun2_2018_2019_bus_plus {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.jun2_2018_2019_bus_plus to javafx.fxml;
    exports com.example.jun2_2018_2019_bus_plus.zadatak1;
}