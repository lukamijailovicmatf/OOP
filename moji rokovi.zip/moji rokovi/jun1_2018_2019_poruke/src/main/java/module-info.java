module com.example.jun1_2018_2019_poruke.zadatak1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.jun1_2018_2019_poruke.zadatak1 to javafx.fxml;
    exports com.example.jun1_2018_2019_poruke.zadatak1;
}