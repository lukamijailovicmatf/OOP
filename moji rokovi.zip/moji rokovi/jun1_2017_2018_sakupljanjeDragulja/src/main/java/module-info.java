module com.example.jun2_2017_2018.zadatak1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.jun2_2017_2018.zadatak1 to javafx.fxml;
    exports com.example.jun2_2017_2018.zadatak1;
}