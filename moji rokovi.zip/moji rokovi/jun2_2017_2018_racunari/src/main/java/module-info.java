module com.example.jun2_2017_2018_racunari {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.jun2_2017_2018_racunari to javafx.fxml;
    exports com.example.jun2_2017_2018_racunari;
}