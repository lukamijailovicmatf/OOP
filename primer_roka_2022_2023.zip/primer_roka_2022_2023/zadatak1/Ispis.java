package zadatak1;

public interface Ispis {
    void prikazi();
}
