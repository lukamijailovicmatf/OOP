package zadatak1;

public class Pravouogaonik extends GeometrijskaFigura {

    // dodatni atributi pravougaonika su njegova duzina i sirina
    private double duzina;
    private double sirina;

    public Pravouogaonik(String ime, double duzina, double sirina) {
        // poziva se konstruktor iz nadklase
        super(ime);
        this.duzina = duzina;
        this.sirina = sirina;
    }

    @Override
    public double povrsina() {
        return duzina * sirina;
    }

    @Override
    public void prikazi() {
        System.out.println("Pravaougaonik" + ime + " sa duzinom " +  duzina + " i sirinom " + sirina);
    }
}
