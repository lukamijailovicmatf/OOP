package com.example.cas12;

public enum Operacija {
    PLUS('+'),
    PUTA('*'),
    MINUS('-'),
    PODELJENO('/'),
    STEPENOVANJE('^');

    Operacija(char c) {}
}
