package kutija;

public class Tacka {
}
