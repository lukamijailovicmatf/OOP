package kutija;

public class MojIzuzetak extends Exception {

    public MojIzuzetak() {
    }

    public MojIzuzetak(String message) {
        super(message);
    }
}
