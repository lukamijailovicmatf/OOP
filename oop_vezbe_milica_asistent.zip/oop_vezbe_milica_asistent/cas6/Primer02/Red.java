package Primer04;

public interface Red {

    void add(int x);
    void remove();
    int head();
    int back();
    int size();
    void show();
}
