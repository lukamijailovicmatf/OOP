package Primer03;

public interface EngleskiJezik {
    void hello();
    void goodbye();
}
