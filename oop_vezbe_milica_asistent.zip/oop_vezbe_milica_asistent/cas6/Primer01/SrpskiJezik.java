package Primer03;

public interface SrpskiJezik {
    void zdravo();
    void dovidjenja();
}
