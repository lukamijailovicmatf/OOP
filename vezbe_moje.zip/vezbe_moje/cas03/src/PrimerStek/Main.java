package PrimerStek;

public class Main {
    public static void main(String[] args) {

        Stek s = new Stek();

        s.push(1);
        s.push(2);
        s.push(3);
        System.out.println(s);

        int x = s.pop();
        if(x == Integer.MAX_VALUE){
            System.err.println("Stek je prazan!");
        }else{
            System.out.println("Skinuli element " + x);
        }

        System.out.println(s);

        int y = s.top();
        if(y == Integer.MAX_VALUE){
            System.err.println("Stek je prazan!");
        }else{
            System.out.println("Na vrhu je element " + y);
        }
    }
}
