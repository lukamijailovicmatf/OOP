module com.example.cas12 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.cas12 to javafx.fxml;
    exports com.example.cas12;
}