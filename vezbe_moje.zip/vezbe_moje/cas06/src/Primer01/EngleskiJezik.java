package Primer01;

public interface EngleskiJezik {
    void hello();
    void goodbye();
}
