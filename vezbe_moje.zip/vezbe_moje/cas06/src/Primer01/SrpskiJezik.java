package Primer01;

public interface SrpskiJezik {
    void zdravo();
    void dovidjenja();
}
