package Primer02;

public interface Red {

    void add(int x); // dodaje element x u red
    void remove(); // uklanja element sa pocetka reda
    int head(); // vraca element na pocetku reda
    int back(); // vraca element na kraju reda
    int size(); // vraca velicinu reda
    void show(); // ispisuje red

}
