package Primer02;

public abstract class Izraz {
    public abstract double izracunaj(); /* metod koji izracunava izraz koji je zadat */
    public abstract Izraz klon(); /* za kloniranje izraza */
}
