import java.util.Scanner;

/* Program racuna elemente Fibonacijevog niza */
public class Primer07 {

    static int fibonaci(int n){

        if(n == 1 || n == 2)
            return 1;
        else
            return fibonaci(n-1) + fibonaci(n-2);

    }

    public static void main(String[] args) {

        Scanner ulaz = new Scanner(System.in);

        int n = ulaz.nextInt();
        //System.out.printf("fibonaci(%d) = %d\n", n, fibonaci(n));
        System.out.println("fibonaci(" + n + ") = " + fibonaci(n));

        ulaz.close();

    }

}
