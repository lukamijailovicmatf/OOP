import java.util.Scanner;

/* Program sumira unete brojeve sve dok se ne unese nula */
public class Primer05 {

    public static void main(String[] args) {

        Scanner ulaz = new Scanner(System.in);

        int suma = 0;
        int x = ulaz.nextInt();

        while(x != 0){
            suma = suma + x;
            x = ulaz.nextInt();
        }

        System.out.println("Suma: " + suma);

        ulaz.close();
    }

}
