import java.util.Scanner;

public class Primer03 {

    public static void main(String[] args) {

        /* Pravimo promenljivu sc tipa Scanner i dodeljujemo joj vrednost. Pravimo Scanner koji
           cita sa standardnog ulaza */
        Scanner sc = new Scanner(System.in);

        System.out.println("Unesite ceo broj:");
        int x = sc.nextInt();
        System.out.println("Uneli ste broj: " + x);

        System.out.println("Unesite realan broj:");
        double y = sc.nextDouble();
        System.out.println("Uneli ste broj: " + y);

        System.out.println("Unesite rec:");
        String rec = sc.next();
        System.out.println("Uneli ste rec: " + rec);

        System.out.println("Unesite 1 karakter:");
        String pom = sc.next();
        char c = pom.charAt(0);
        System.out.println("Uneli ste karakter: " + c);

        /* Zatvaramo Scanner */
        sc.close();

    }

}
