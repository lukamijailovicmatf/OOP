import java.util.Scanner;

/* Program prikazuje sve parne brojeve iz intervala od [2, n] */
public class Primer06 {

    static void ispisiParne(int n){

        for(int i=2; i<=n; i+=2)
            System.out.print(i + " ");
        System.out.println();

    }

    public static void main(String[] args) {

        Scanner ulaz = new Scanner(System.in);

        int n = ulaz.nextInt();
        ispisiParne(n);

        ulaz.close();

    }

}
