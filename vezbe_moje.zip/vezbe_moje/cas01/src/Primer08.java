import java.util.Scanner;

/* Karakteri su jedan od primitivnih tipova koji postoje u Javi. Scanner nema metod koji ucitava karakter
   tako da se mozemo dovijati koristeci metod 'next' koji vraca ucitanu rec, a onda od nje mozemo izdvojiti
   nulti karakter. Klasa Character sadrzi vise statickih funkcija koje mozemo koristiti za rad sa
   karakterima. */
public class Primer08 {

    public static void main(String[] args) {

        Scanner ulaz = new Scanner(System.in);

        char x = 'd';

        if(ulaz.hasNext()){
            String pom = ulaz.next();
            x = pom.charAt(0);
        }else{
            System.out.println("Greska, nije uneta rec ili karakter!");
            System.exit(1);
        }

        System.out.println("Unet karakter: " + x);

        if(Character.isUpperCase(x)){
            System.out.println(x + " je veliko slovo.");
            System.out.println("Mozemo ga zapisati i kao malo slovo: " + Character.toLowerCase(x));
        }else if(Character.isLowerCase(x)){
            System.out.println(x + " je malo slovo.");
            System.out.println("Mozemo ga zapisati i kao veliko slovo: " + Character.toUpperCase(x));
        }else if(Character.isDigit(x)){
            System.out.println(x + " je cifra");
            int y = Character.getNumericValue(x);
            System.out.println("Numericka vrednost cifre: " + y);
        }

        ulaz.close();

    }

}
