import java.util.Scanner;

public class Primer04 {

    public static void main(String[] args) {

        /* Ukoliko zelimo da proverimo da li je korisnik uneo podatak koji je tipa koji zelimo da
           unesemo, mozemo koristiti metode klase Scanner koji pocinju sa has */
        Scanner ulaz = new Scanner(System.in);

        int x = 0;
        System.out.println("Unesite ceo broj:");

        if(ulaz.hasNextInt()){
            x = ulaz.nextInt();
            System.out.println("Uneli ste broj: " + x);
        }else{
            System.out.println("Niste uneli ceo broj. Greska...");
            System.exit(1);
        }

        double y = 0.0;
        System.out.println("Unesite realan broj: ");

        if(ulaz.hasNextDouble()){
            y = ulaz.nextDouble();
            System.out.println("Uneli ste realan broj: " + y);
        }else{
            System.out.println("Niste uneli realan broj. Greska...");
            System.exit(1);
        }

        ulaz.close();

    }

}
