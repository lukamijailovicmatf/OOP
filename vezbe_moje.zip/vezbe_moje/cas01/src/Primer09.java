import java.util.Scanner;

public class Primer09 {

    static double uStepene(double radijan){

        return (radijan * 180) / Math.PI;

    }

    static double uRadijane(double stepen){

        return (stepen * Math.PI) / 180;

    }

    public static void main(String[] args) {

        /* Klasa Math sadrzi vise statickih funkcija vezanih za matematiku */
        Scanner ulaz = new Scanner(System.in);



        ulaz.close();

    }

}
