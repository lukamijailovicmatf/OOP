public class Primer01 {

    public static void main(String[] args) {

        /* Deklarisemo promenljive i dodeljujemo im vrednosti */
        int x = 10;
        int y = 25;
        //int z = x + y;

        /* Vrednost promenljive z ispisujemo kao string */
        //System.out.println(z);

        /* Izracunava se vrednost izraza x+y i ispisuje se na standardni izlaz */
        //System.out.println(x+y);

        /* Primetimo da se vrednost izraza x+y prebacuje u String i spaja sa String-om "Zbir: " */
        //System.out.println("Zbir: " + (x+y));

        /* Pravimo primenljivu tipa String koju cemo nazvati str */
        String str = "Zdravo";

        /* Dodajemo stringu razmak */
        str = str + " ";

        /* Stringove mozemo spajati koristeci operator + */
        str = str + "svete!";

        /* Ispisujemo rezultat na standardni izlaz */
        System.out.println(str);
    }
}
